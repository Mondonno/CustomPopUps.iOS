﻿using System;
using System.Threading.Tasks;

namespace CPopupLibrary
{
    public class PopUpsObjects : CustomPopUpViewController
    {
        //Working on it...
        
        public enum AniamtionType
        {
            Normal,
            Slide,
            Bounce
        }
        public enum Animated
        {
            Yes,
            No,
        }
    }
}
